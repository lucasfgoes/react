const express = require('express');
const app = express();
const cors = require('cors');
const sequelize = require('sequelize');
const models = require('./models');
const port = 3001;

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

let usuario = models.Usuario;

app.post('/', async (req, res) => {
  
  console.log(req.body.usuario);
  console.log(req.body.senha);

  let response = await usuario.findOne({
    where:{
      nome:req.body.usuario,
      senha:req.body.senha
    }
  });

  if(response){
  let {nome,senha} =  response.dataValues;
  res.send(JSON.stringify({nome,senha}));
  }
  else res.send(JSON.stringify(null));
});

app.listen(port, () => {
  console.log(`server running in http://localhost:${port}`)
});