import React, { useState, useEffect } from "react";
import { Routes, Route } from "react-router-dom";
import { Login } from "./pages/Login";
import Main from "./pages/Main";
import Cadastro from "./pages/Cadastro";
import Consulta from "./pages/Consulta";

// eslint-disable-next-line import/no-anonymous-default-export
export default () => {
  const [auth, setAuth] = useState(false);

  useEffect(() => {
    let getAuth = JSON.parse(sessionStorage.getItem("auth"));
    setAuth(getAuth);
  });

  const privateRouteLogin = () =>
    auth ? (
      <Route exact path="/" element={<Main />} />
    ) : (
      <Route exact path="/" element={<Login />} />
    );

  const privateRouteCadastro = () =>
    auth ? (
      <Route exact path="/cadastro" element={<Cadastro />} />
    ) : (
      <Route exact path="/cadastro" element={<h1>fazer login.</h1>} />
    );

  const privateRouteConsulta = () =>
    auth ? (
      <Route exact path="/consulta" element={<Consulta />} />
    ) : (
      <Route exact path="/consulta" element={<h1>fazer login.</h1>} />
    );

  return (
    <Routes>
      {privateRouteLogin()}
      {privateRouteCadastro()}
      {privateRouteConsulta()}
    </Routes>
  );
};
