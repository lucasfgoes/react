import React from "react";
import "./styles.css";

function Footer() {
  return (
    <footer>
      <h1>Pedreira Bike Fit</h1>
      <p>todos os direitos reservados.</p>
    </footer>
  );
}

export default Footer;
