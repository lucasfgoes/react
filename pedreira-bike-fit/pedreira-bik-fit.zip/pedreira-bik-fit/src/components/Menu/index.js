import React from "react";
import "./styles.css";

function Menu() {
  return (
    <header className="">
      <div className="container-menu">
        <div className="logo-menu">
          <img src="/logo3.png" alt="logo" />
        </div>
        <nav>
          <a href="/cadastro">Cadastrar Ciclista</a>
          <a href="/consulta">Consultar</a>
        </nav>
      </div>
    </header>
  );
}

export default Menu;
