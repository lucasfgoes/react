import React from "react";
import "./cadastro.css";
import Menu from "../../components/Menu";
import Footer from "../../components/Footer";

function Cadastro() {
  return (
    <>
      <Menu />

      <form className="form" action="">
        <h1>Cadastro de ciclista</h1>
        <h2>Identificação</h2>

        <div className="item">
          <label htmlFor="nome">Nome:</label>
          <input type="text" id="nome" name="nome" />
          <label htmlFor="rg">RG:</label>
          <input type="text" id="rg" name="rg" />
          <label htmlFor="cpf">CPF:</label>
          <input
            id="cpf"
            type="text"
            className="form-control cpf-mask"
            placeholder="Ex.: 000.000.000-00"
          />
          <label>Sexo:</label>
          <select name="select" required>
            <option value="masculino">Masculino</option>
            <option value="feminino">Feminino</option>
          </select>
          <label htmlFor="nascimento">Nascimento:</label>
          <input type="date" id="nascimento" name="nascimento" />
        </div>

        <div className="item">
          <label htmlFor="profissao">Profissão:</label>
          <input type="text" id="profissao" name="profissao" />
          <label htmlFor="email">E-mail:</label>
          <input type="email" id="email" name="email" />
        </div>

        <div className="item">
          <label htmlFor="obs">Observações do usuário:</label>
          <textarea name="obs" id="obs" cols="30" rows="10"></textarea>
        </div>

        <h2>Contato</h2>
        <label htmlFor="cep">CEP:</label>
        <input type="text" id="cep" name="cep" />
        <label htmlFor="rua">Rua:</label>
        <input type="text" id="rua" name="rua" />
        <label htmlFor="numero">Número:</label>
        <input type="text" id="numero" name="numero" />
        <label htmlFor="bairro">Bairro:</label>
        <input type="text" id="bairro" name="bairro" />
        <label htmlFor="complemento">Complemento:</label>
        <input type="text" id="complemento" name="complemento" />
        <label htmlFor="estado">Estado:</label>
        <select id="estado" name="estado">
          <option value="AC">Acre</option>
          <option value="AL">Alagoas</option>
          <option value="AP">Amapá</option>
          <option value="AM">Amazonas</option>
          <option value="BA">Bahia</option>
          <option value="CE">Ceará</option>
          <option value="DF">Distrito Federal</option>
          <option value="ES">Espírito Santo</option>
          <option value="GO">Goiás</option>
          <option value="MA">Maranhão</option>
          <option value="MT">Mato Grosso</option>
          <option value="MS">Mato Grosso do Sul</option>
          <option value="MG">Minas Gerais</option>
          <option value="PA">Pará</option>
          <option value="PB">Paraíba</option>
          <option value="PR">Paraná</option>
          <option value="PE">Pernambuco</option>
          <option value="PI">Piauí</option>
          <option value="RJ">Rio de Janeiro</option>
          <option value="RN">Rio Grande do Norte</option>
          <option value="RS">Rio Grande do Sul</option>
          <option value="RO">Rondônia</option>
          <option value="RR">Roraima</option>
          <option value="SC">Santa Catarina</option>
          <option value="SP">São Paulo</option>
          <option value="SE">Sergipe</option>
          <option value="TO">Tocantins</option>
        </select>
        <label htmlFor="cidade">Cidade:</label>
        <input type="text" id="cidade" name="cidade" />
        <label htmlFor="telefone">Telefone com DDD:</label>
        <input type="text" id="telefone" name="telefone" />
      </form>

      <Footer />
    </>
  );
}

export default Cadastro;
