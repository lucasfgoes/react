import React from "react";
import "./consulta.css";
import Menu from "../../components/Menu";
import Footer from "../../components/Footer";

function Consulta() {
  return (
    <>
      <Menu />
      <form action="" className="form">
        <h1>Consulta de ciclista</h1>

        <label htmlFor="nome">Nome:</label>
        <input id="nome" type="text" name="nome" />
      </form>
      <Footer />
    </>
  );
}

export default Consulta;
