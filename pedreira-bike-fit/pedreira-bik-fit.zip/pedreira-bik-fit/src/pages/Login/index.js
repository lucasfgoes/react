/* eslint-disable no-restricted-globals */
import React,{useState} from "react";
import "./login.css";
import { MdAccountCircle, MdLock } from "react-icons/md";
import Button from "../../components/Button";
import {Auth} from "../auth";

export function Login() {
  const [usuario,setUsuario] = useState(null);
  const [senha,setSenha] = useState(null);
  
async function enviaForm(e){
   e.preventDefault();
   let autorizado = await Auth(usuario,senha);
   if(!autorizado) alert('usuário ou senha inválidos!');
   else {
     history.pushState(null,null,'/');
     location.href = '/';
    }
}

  return (
    <>
      <form id="login" className="login" onSubmit={e=>enviaForm(e)}>
        <div className="login-logo">
          <img src="logo2.png" alt="Logo" />
        </div>

        <div className="login-right">
          <h1>Acesso:</h1>
          <MdAccountCircle className="icon"/>
          <div className="loginInputUsuario">
            <input type="text" placeholder="Usuário:" name="usuario" onChange={e=>{setUsuario(e.target.value)}}/>
          </div>

          <MdLock className="icon"/>
          <div className="loginInputPassword">
            <input type="password" placeholder="Senha:" name="senha" onChange={e=>{setSenha(e.target.value)}}/>
          </div>

          <div className="container-btn">
            <Button>Entrar</Button>
          </div>
        </div>
      </form>
    </>
  );
}


