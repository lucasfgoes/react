import React from "react";
import "./main.css";
import Title from "../../components/Title";
import Menu from "../../components/Menu";
import Footer from "../../components/Footer";

function Main() {
  return (
    <>
      <div className="container-main">
        <Menu />
        <Title>Pedreira Bike Fit</Title>
        <div className="img">
          <img src="/bike1.jpg" alt="bike1" />
        </div>
        <div className="img">
          <img src="/bike2.jpg" alt="bike2" />
        </div>
        <div className="img">
          <img src="/bike3.jpg" alt="bike3" />
        </div>

        <Footer />
      </div>
    </>
  );
}

export default Main;
