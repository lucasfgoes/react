export const Auth =  (usuario,senha)=>{

    async function enviaForm(){
      //enviando requisição para API
      let response = await fetch('http://localhost:3001',{
      method: 'POST',
      body: JSON.stringify({usuario,senha}),
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
  });

    let json = await response.json();
    sessionStorage.setItem('auth',JSON.stringify(!!json));
    return !!json;
    }

 return enviaForm();
}
